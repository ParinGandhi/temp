export class ToastrModel {
    showToast: boolean = false;
    toastLevel: string = null;
    toastMessage: string = null;

    constructor() {}
}