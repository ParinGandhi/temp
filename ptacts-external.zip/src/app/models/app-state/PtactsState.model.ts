export default interface PtactsStateModel {
  userId: string;
}
