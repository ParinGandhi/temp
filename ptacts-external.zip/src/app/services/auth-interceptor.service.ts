/**
 * ! This will intercept all http requests. This is where we can add properties to the header
 * ! using .append(). Also, the 'req' object in the intercept method has the url and other info
 * ! in case we need to perform any logic for adding properties to the header
 */

import { HttpHandler, HttpInterceptor, HttpRequest } from "@angular/common/http";
import { Store, select } from '@ngrx/store';
import { PtactsState } from 'src/app/store/ptacts/ptacts.state';
import * as PtactsSelectors from 'src/app/store/ptacts/ptacts.selectors';
import { take, exhaustMap, map } from 'rxjs/operators';
import { Injectable } from "@angular/core";
import { NGXLogger } from "ngx-logger";


@Injectable()
export class AuthInterceptorService implements HttpInterceptor {

    constructor(private store: Store<PtactsState>, private logger: NGXLogger) {

    }

    intercept(req: HttpRequest<any>, next: HttpHandler) {
        return this.store.select(PtactsSelectors.ptactsStateData).pipe(
            take(1),
            map(stateData => {
                console.log('stateData: ', stateData);
                return stateData.userId;
            }),
            exhaustMap(userId => {
                if (!userId) {
                    return next.handle(req)
                }
                this.logger.trace('This is a trace statement');
                this.logger.debug('This is a debug statement: ', userId);
                this.logger.info('This is a info statement', userId);
                this.logger.log('This is a log statement', userId);
                this.logger.warn('This is a warn statement', userId);
                this.logger.error('This is a error statement', userId);
                this.logger.fatal('This is a fatal statement', userId);

                const modifiedRequest = req.clone({ headers: req.headers.append('user-id', userId) });
                return next.handle(modifiedRequest)
            })
        )
    }
}