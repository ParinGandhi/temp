import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { AiaAppealsComponent } from './components/my-docket/aia-appeals/aia-appeals.component';
import { AllAiaReviewsComponent } from './components/my-docket/all-aia-reviews/all-aia-reviews.component';
import { MotionsRehearingsComponent } from './components/my-docket/motions-rehearings/motions-rehearings.component';
import { MyDocketComponent } from './components/my-docket/my-docket.component';
import { NotificationsComponent } from './components/my-docket/notifications/notifications.component';
import { UnsubmittedPetitionsComponent } from './components/my-docket/unsubmitted-petitions/unsubmitted-petitions.component';
import { UsersComponent } from './components/users/users.component';

const routes: Routes = [
  {
    path: '',
    component: LoginComponent,
  },
  {
    path: 'users',
    component: UsersComponent,
  },
  {
    path: 'myDocket',
    component: MyDocketComponent,
    children: [
      {
        path: 'all-aia-reviews',
        component: AllAiaReviewsComponent,
      },
      {
        path: 'notifications',
        component: NotificationsComponent,
      },
      {
        path: 'motions-rehearings',
        component: MotionsRehearingsComponent,
      },
      {
        path: 'aia-appeals',
        component: AiaAppealsComponent,
      },
      {
        path: 'unsubmitted-petitions',
        component: UnsubmittedPetitionsComponent,
      },
    ],
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
      onSameUrlNavigation: 'reload',
      useHash: true,
    }),
  ],
  exports: [RouterModule],
})
export class AppRoutingModule {}
