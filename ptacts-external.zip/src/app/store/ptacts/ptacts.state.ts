/**
 * !The interface can be modified bu adding properties/objects to it.
 * !The same structure has to be present in the initializeState function below it.
 */

export interface PtactsState {
  userId: string;
  isLoading: boolean
}

export const initializeState = (): PtactsState => {
  return {
    userId: 'Initial ID',
    isLoading: false
  };
};
