/**
 * !We can create new selectors based on what we need to return.
 * !Currently, the selector is returning the entire state
 */
import { createFeatureSelector, createSelector } from '@ngrx/store';
import { PtactsState } from './ptacts.state';

const ptactsData = createFeatureSelector<PtactsState>('ptactsState');

export const ptactsStateData = createSelector(ptactsData, (s) => s);
