export class PtactsEffects {}
