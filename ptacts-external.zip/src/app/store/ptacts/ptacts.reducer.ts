/**
 * ! A new reducer can be added based on what needs to be added to or accessed from the state
 */
import { Action, createReducer, on } from '@ngrx/store';
import * as PtactsActions from './ptacts.actions';
import { PtactsState, initializeState } from './ptacts.state';

const initialState = initializeState();

const reducer = createReducer(
  initialState,
  on(PtactsActions.setUserIdAction, (state: PtactsState, { payload }) => {
    return { ...state, userId: payload };
  }),
  on(PtactsActions.getUserIdAction, (state: PtactsState, { request }) => {
    return { ...state, userId: request };
  }),
  on(PtactsActions.changeLoading, (state: PtactsState, { request }) => {
    return { ...state, isLoading: request };
  })
);

export function ptactsReducer(state: PtactsState | undefined, action: Action) {
  return reducer(state, action);
}
