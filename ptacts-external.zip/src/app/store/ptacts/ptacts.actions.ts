/**
 * ! Create a new action based on needs
 */
import { createAction, props } from '@ngrx/store';

export const setUserIdAction = createAction(
  '[PtactsState] Set user ID',
  props<{ payload: any }>()
);

export const getUserIdAction = createAction(
  '[PtactsState] Get user ID',
  props<{ request: any }>()
);

export const changeLoading = createAction(
  '[PtactsState] Change loading',
  props<{ request: boolean }>()
);
