import { ActionReducerMap } from '@ngrx/store';

import { PtactsState } from './ptacts/ptacts.state';
import { ptactsReducer } from './ptacts/ptacts.reducer';

export interface State {
  ptactsState: PtactsState;
}

export const reducers: ActionReducerMap<State> = {
  ptactsState: ptactsReducer,
};
