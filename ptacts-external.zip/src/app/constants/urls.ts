/**
 * ! Constant file for handling all URLS
 * ! Try to follow this naming convention:
 *
 * ! API_FUNCTION_DESCRIPTION: {
 * !    GET:
 * !    POST:
 * !    PUT:
 * !    DELETE:
 * ! }
 */
export const Urls = {
    USERS: {
        GET: 'https://jsonplaceholder.typicode.com/users'
    }
}