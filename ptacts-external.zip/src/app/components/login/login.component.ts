import { Component, OnInit } from '@angular/core';

import { Store } from '@ngrx/store';
import { PtactsState } from 'src/app/store/ptacts/ptacts.state';
import { changeLoading, setUserIdAction } from 'src/app/store/ptacts/ptacts.actions';

import { NGXLogger } from 'ngx-logger';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.less'],
})
export class LoginComponent implements OnInit {
  userId: string;

  constructor(private logger: NGXLogger, private store: Store<PtactsState>) {}

  ngOnInit(): void {}

  login() {
    this.store.dispatch(setUserIdAction({ payload: this.userId }));

    //const userInfo = {
    //   firstName: 'Parin',
    //   lastName: 'Gandhi',
    //   project: 'P-TACTS',
    // };
    // const namesList = ['Parin', 'Payal', 'Anand', 'Khushi'];
    // this.logger.trace('This is a trace statement');
    // this.logger.debug('LoginComponent: ', userInfo);
    // this.logger.info('This is a info statement', namesList);
    // this.logger.log('This is a log statement');
    // this.logger.warn('This is a warn statement');
    // this.logger.error('This is a error statement');
    // this.logger.fatal('This is a fatal statement');
  }


  changeLoading() {
    this.store.dispatch(changeLoading({ request: true }));
  }
}
