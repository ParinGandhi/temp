/**
 * ! Component for handling user related tasks.
 * ! Business logic should be separated into its own service file
 */
import { Component, OnInit } from '@angular/core';
import { take } from 'rxjs/operators';
import { UsersService } from 'src/app/services/users.service';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.less']
})
export class UsersComponent implements OnInit {

  usersList: [] = [];

  constructor(private usersService: UsersService) { }

  ngOnInit(): void {
    this.getUsers();
  }

  getUsers() {
    this.usersService.getUsers().pipe(take(1)).subscribe((users) => {
      this.usersList = users;
    })
  }

}
