import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aia-appeals',
  templateUrl: './aia-appeals.component.html',
  styleUrls: ['./aia-appeals.component.scss']
})
export class AiaAppealsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
