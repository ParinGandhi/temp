import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AiaAppealsComponent } from './aia-appeals.component';

describe('AiaAppealsComponent', () => {
  let component: AiaAppealsComponent;
  let fixture: ComponentFixture<AiaAppealsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AiaAppealsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AiaAppealsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
