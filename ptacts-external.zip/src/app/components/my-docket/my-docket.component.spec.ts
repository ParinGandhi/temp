import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MyDocketComponent } from './my-docket.component';

describe('MyDocketComponent', () => {
  let component: MyDocketComponent;
  let fixture: ComponentFixture<MyDocketComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MyDocketComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MyDocketComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
