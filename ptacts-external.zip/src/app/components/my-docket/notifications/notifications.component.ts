import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.scss'],
})
export class NotificationsComponent implements OnInit {
  gridOptions = {
    columnDefs: [],
    rowData: [],
    headerHeight: 48,
    defaultColDef: {
      filter: true,
      sortable: true,
      floatingFilter: true,
      suppressMenu: true,
      // tooltipComponent: 'customTooltip',
    },
  };

  gridApi;
  gridColumnApi;
  numberOfFilters: number = 0;

  constructor() {}

  ngOnInit(): void {
    this.gridOptions.columnDefs = [
      { field: 'aiaReviewNumber', headerName: 'AIA Review #' },
      { field: 'filingDate', headerName: 'Send to' },
      { field: 'petitionerApplicationNumber', headerName: 'Message' },
      { field: 'petitionerPatentNumber', headerName: 'Sent on' },
      { field: 'petitionerName', headerName: 'Action' },
    ];
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
  }

  onFilterChanged() {
    const filterModel = this.gridApi.getFilterModel();
    if (filterModel) {
      this.numberOfFilters = Object.keys(filterModel).length;
    }
  }

  clearFilters() {
    this.gridApi.setFilterModel(null);
    this.onFilterChanged();
  }
}
