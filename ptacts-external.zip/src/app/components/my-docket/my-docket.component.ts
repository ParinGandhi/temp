import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-docket',
  templateUrl: './my-docket.component.html',
  styleUrls: ['./my-docket.component.less']
})
export class MyDocketComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
