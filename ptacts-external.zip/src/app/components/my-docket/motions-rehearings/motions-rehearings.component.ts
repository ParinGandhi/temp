import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-motions-rehearings',
  templateUrl: './motions-rehearings.component.html',
  styleUrls: ['./motions-rehearings.component.scss']
})
export class MotionsRehearingsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
