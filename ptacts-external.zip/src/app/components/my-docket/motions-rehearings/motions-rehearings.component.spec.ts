import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MotionsRehearingsComponent } from './motions-rehearings.component';

describe('MotionsRehearingsComponent', () => {
  let component: MotionsRehearingsComponent;
  let fixture: ComponentFixture<MotionsRehearingsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MotionsRehearingsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MotionsRehearingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
