import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UnsubmittedPetitionsComponent } from './unsubmitted-petitions.component';

describe('UnsubmittedPetitionsComponent', () => {
  let component: UnsubmittedPetitionsComponent;
  let fixture: ComponentFixture<UnsubmittedPetitionsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UnsubmittedPetitionsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UnsubmittedPetitionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
