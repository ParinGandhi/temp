import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-unsubmitted-petitions',
  templateUrl: './unsubmitted-petitions.component.html',
  styleUrls: ['./unsubmitted-petitions.component.scss'],
})
export class UnsubmittedPetitionsComponent implements OnInit {
  gridOptions = {
    columnDefs: [],
    rowData: [],
    headerHeight: 48,
    defaultColDef: {
      filter: true,
      sortable: true,
      floatingFilter: true,
      suppressMenu: true,
      // tooltipComponent: 'customTooltip',
    },
  };

  gridApi;
  gridColumnApi;
  numberOfFilters: number = 0;

  constructor() {}

  ngOnInit(): void {
    this.gridOptions.columnDefs = [
      { field: 'aiaReviewNumber', headerName: 'AIA Review #' },
      { field: 'filingDate', headerName: 'Filing date' },
      {
        field: 'petitionerApplicationNumber',
        headerName: 'Petitioner application #',
      },
      { field: 'petitionerPatentNumber', headerName: 'Petitioner patent #' },
      { field: 'petitionerName', headerName: 'Petitioner name' },
      {
        field: 'poRespondentApplicationNumber',
        headerName: 'PO/Respondent app #',
      },
      {
        field: 'poRespondentPatentNumber',
        headerName: 'PO/Responsent patent #',
      },
      { field: 'poRespondentName', headerName: 'PO/Respondent name' },
      { field: 'status', headerName: 'Status' },
    ];
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
  }

  onFilterChanged() {
    const filterModel = this.gridApi.getFilterModel();
    if (filterModel) {
      this.numberOfFilters = Object.keys(filterModel).length;
    }
  }

  clearFilters() {
    this.gridApi.setFilterModel(null);
    this.onFilterChanged();
  }
}
