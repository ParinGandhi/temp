import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpcomingDueDatesComponent } from './upcoming-due-dates.component';

describe('UpcomingDueDatesComponent', () => {
  let component: UpcomingDueDatesComponent;
  let fixture: ComponentFixture<UpcomingDueDatesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpcomingDueDatesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpcomingDueDatesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
