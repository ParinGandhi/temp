import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-upcoming-due-dates',
  templateUrl: './upcoming-due-dates.component.html',
  styleUrls: ['./upcoming-due-dates.component.scss']
})
export class UpcomingDueDatesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
