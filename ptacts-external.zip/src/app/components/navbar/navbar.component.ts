import { Component, OnInit } from '@angular/core';

import { Store, select } from '@ngrx/store';
import { PtactsState } from 'src/app/store/ptacts/ptacts.state';
import * as PtactsSelectors from 'src/app/store/ptacts/ptacts.selectors';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.less'],
})
export class NavbarComponent implements OnInit {
  loggedInUser$ = this.store.pipe(select(PtactsSelectors.ptactsStateData));

  constructor(private store: Store<PtactsState>) {}

  ngOnInit(): void {}
}
