import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-toastr',
  templateUrl: './toastr.component.html',
  styleUrls: ['./toastr.component.less']
})
export class ToastrComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
