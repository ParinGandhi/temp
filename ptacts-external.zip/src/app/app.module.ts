import { environment } from 'src/environments/environment';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

import { LoggerModule } from 'ngx-logger';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';

import { StoreModule } from '@ngrx/store';
import { reducers } from './store/ptacts-app-store';
import { EffectsModule } from '@ngrx/effects';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { PtactsEffects } from './store/ptacts/ptacts.effects';

import { AgGridModule } from 'ag-grid-angular';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { FooterComponent } from './components/footer/footer.component';
import { LoginComponent } from './components/login/login.component';
import { UsersComponent } from './components/users/users.component';
import { MyDocketComponent } from './components/my-docket/my-docket.component';

import { AuthInterceptorService } from './services/auth-interceptor.service';
import { AllAiaReviewsComponent } from './components/my-docket/all-aia-reviews/all-aia-reviews.component';
import { NotificationsComponent } from './components/my-docket/notifications/notifications.component';
import { MotionsRehearingsComponent } from './components/my-docket/motions-rehearings/motions-rehearings.component';
import { AiaAppealsComponent } from './components/my-docket/aia-appeals/aia-appeals.component';
import { UnsubmittedPetitionsComponent } from './components/my-docket/unsubmitted-petitions/unsubmitted-petitions.component';
import { UpcomingDueDatesComponent } from './components/my-docket/upcoming-due-dates/upcoming-due-dates.component';
@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    FooterComponent,
    LoginComponent,
    UsersComponent,
    MyDocketComponent,
    AllAiaReviewsComponent,
    NotificationsComponent,
    MotionsRehearingsComponent,
    AiaAppealsComponent,
    UnsubmittedPetitionsComponent,
    UpcomingDueDatesComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    EffectsModule.forRoot([PtactsEffects]),
    StoreModule.forRoot(reducers, {
      runtimeChecks: {
        strictActionImmutability: true,
        strictActionSerializability: true,
        strictStateImmutability: true,
        strictStateSerializability: true,
      },
    }),
    StoreDevtoolsModule.instrument({ maxAge: 10 }),
    LoggerModule.forRoot({
      serverLoggingUrl: '/api/logs', //? Add path to server to write the logs
      level: environment.logLevel, //? Log level to show in browser console
      serverLogLevel: environment.serverLogLevel, //? Log level to show on the server
    }),
    BrowserAnimationsModule,
    TabsModule.forRoot(),
    BsDropdownModule.forRoot(),
    AgGridModule.withComponents([]),
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptorService,
      multi: true,
    },
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
