import { Injectable } from "@angular/core";

@Injectable({
    providedIn: 'root'
})
export class CommonUtilitiesService {

    constructor() {

    }

    generateRandomNumber() {
        return Math.floor(Math.random() * 100) + 1;
    }
}